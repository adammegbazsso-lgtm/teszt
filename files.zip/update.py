"""TippMester: meccsek + valós oddsok (API-Football) + AI tippek (Claude). Futtatás: python update.py"""
import os, json, re, datetime, urllib.request, urllib.parse
from zoneinfo import ZoneInfo

AF_KEY = os.environ["API_FOOTBALL_KEY"]
AI_KEY = os.environ.get("ANTHROPIC_API_KEY")
LEAGUES = {2, 3, 848, 39, 140, 135, 78, 61, 271}  # BL, EL, KL, PL, La Liga, Serie A, Bundesliga, Ligue 1, NB I
BOOKS = ["Bet365", "Unibet", "Bwin", "Pinnacle"]   # ezek közül amit az API ad
MAX_NEW = 20                                        # max ennyi új meccsre kérünk oddsot/tippet futásonként
FINISHED = {"FT", "AET", "PEN"}
LIVE = {"1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT"}

def af(path, **q):
    req = urllib.request.Request("https://v3.football.api-sports.io/%s?%s" % (path, urllib.parse.urlencode(q)),
                                 headers={"x-apisports-key": AF_KEY})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r).get("response", [])

def parse_odds(resp):
    """-> {"over_2.5": {"Bet365": 1.85, ...}, ...}"""
    out = {}
    def put(k, b, o):
        out.setdefault(k, {})[b] = float(o)
    for item in resp[:1]:
        for bm in item.get("bookmakers", []):
            if bm["name"] not in BOOKS: continue
            for bet in bm["bets"]:
                for v in bet["values"]:
                    n, val, odd = bet["name"], str(v["value"]), v["odd"]
                    if n == "Match Winner":
                        put({"Home": "home", "Draw": "draw", "Away": "away"}.get(val, "x"), bm["name"], odd)
                    elif n == "Goals Over/Under" and val in ("Over 1.5", "Over 2.5", "Over 3.5", "Under 2.5", "Under 3.5"):
                        put(val.lower().replace(" ", "_"), bm["name"], odd)
                    elif n == "Both Teams Score" and val == "Yes":
                        put("btts_yes", bm["name"], odd)
    out.pop("x", None)
    return out

def ask_claude(cands):
    prompt = ("Te egy óvatos, adatalapú foci-elemző vagy. Minden meccshez válassz 2-3 fogadási tippet a megadott "
              "piacok (pick kulcsok) közül, az oddsok és a csapatok erőssége alapján. Válaszolj KIZÁRÓLAG JSON-nal: "
              '{"<meccs_id>":[{"pick":"<kulcs>","conf":<50-85 egész>,"why":"<max 12 szavas magyar indoklás>"}]}\n\n'
              + json.dumps(cands, ensure_ascii=False))
    body = json.dumps({"model": "claude-sonnet-5-5", "max_tokens": 4000,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", body,
                                 {"x-api-key": AI_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        text = json.load(r)["content"][0]["text"]
    return json.loads(re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip())

def main():
    tz = ZoneInfo("Europe/Budapest")
    today = datetime.datetime.now(tz).date().isoformat()
    old = {}
    if os.path.exists("data.json"):
        d = json.load(open("data.json", encoding="utf-8"))
        if d.get("date") == today:
            old = {m["id"]: m for m in d["matches"]}
    matches, cands, odds_by_id = [], {}, {}
    for f in af("fixtures", date=today, timezone="Europe/Budapest"):
        if f["league"]["id"] not in LEAGUES: continue
        st = f["fixture"]["status"]["short"]
        m = {"id": f["fixture"]["id"], "league": f["league"]["name"], "kickoff": f["fixture"]["date"],
             "home": f["teams"]["home"]["name"], "away": f["teams"]["away"]["name"],
             "hl": f["teams"]["home"]["logo"], "al": f["teams"]["away"]["logo"],
             "status": "fin" if st in FINISHED else "live" if st in LIVE else "ns",
             "minute": f["fixture"]["status"]["elapsed"],
             "score": [f["goals"]["home"] or 0, f["goals"]["away"] or 0],
             "tips": old.get(f["fixture"]["id"], {}).get("tips", [])}
        matches.append(m)
        if not m["tips"] and m["status"] == "ns" and len(cands) < MAX_NEW:
            odds = parse_odds(af("odds", fixture=m["id"]))
            if odds:
                odds_by_id[m["id"]] = odds
                cands[m["id"]] = {"meccs": m["home"] + " - " + m["away"], "liga": m["league"],
                                  "piacok": {k: max(v.values()) for k, v in odds.items()}}
    if cands and AI_KEY:
        try:
            ai = ask_claude(cands)
            for m in matches:
                for t in ai.get(str(m["id"]), []):
                    o = odds_by_id[m["id"]].get(t.get("pick"))
                    if o: m["tips"].append({"pick": t["pick"], "conf": int(t["conf"]), "why": t.get("why", ""), "odds": o})
        except Exception as e:
            print("AI hiba:", e)
    matches.sort(key=lambda m: m["kickoff"])
    json.dump({"date": today, "updated": datetime.datetime.now(tz).isoformat(timespec="minutes"), "matches": matches},
              open("data.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(len(matches), "meccs,", len(cands), "új tippelt")

main()
